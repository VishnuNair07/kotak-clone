import React from 'react'
import './Home.css'
import Cardfirst from '../../components/Card/Section1/Cardfirst'
const Home = () => {
  return (
    <div>
       <div class="main-page">
    <img className="img1" src="https://www.kotak.com/content/dam/Kotak/herosliderbanner/newhomepage-activmoney-d.jpg" alt="main-page" />
    <img className='img2' src="https://www.kotak.com/content/dam/Kotak/mobile_images/activ-money-m.jpg" alt="main-page" />
    <div className="image-text">

    <h1 class="image-h1">Earn FD-wala interest up to 7%* p.a. in Savings Account with ActivMoney</h1>
    <p className='p'>To know more, <span><a href='/'  style={{color : "red" ,textDecoration: "none"}}> click here</a></span></p>

    <div className="btn-box">
      <button className='button-5'><p style={{color : "#fff"}}>Open a Kotak Savings Account</p></button>
      <button className='button-5'><p style={{color : "#fff"}}>Existing Customer ? Activate</p></button>
    </div>
    </div>
  </div>
    <Cardfirst/>
    </div>
  )
}

export default Home

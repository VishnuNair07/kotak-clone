import React from 'react';
import './Navbar.css';
import Home from '../../pages/Home/Home';
import Dropdown from '../Dropdown/Dropdown';

const Navbar = () => {


  return (
    <div>
        <nav className="upper-nav">
            <div className="upper-li">

            <ul>
                <li className='main-paragraph hover_effect active'>personal</li>
                <li className='main-paragraph hover_effect'>Business</li>
                <li className='main-paragraph hover_effect'>Corporate</li>
                <li className='main-paragraph hover_effect'>private banking</li>
                <li className='main-paragraph hover_effect'>privy League</li>
                <li className='main-paragraph hover_effect'>nri services</li>
                <li className='main-paragraph hover_effect'>investors</li>
            </ul>
            </div>
            <div className="upper-search">
                <ul>
                    <li><i class='bx bx-search-alt-2' ></i>Search</li>
                    <li><i class='bx bx-help-circle' ></i>Help Center</li>
                    <li><i class='bx bx-location-plus'></i>Locate us</li>
                </ul>
            </div>
        </nav>
      <nav className='lower-nav'>
          <div className="logo-center">
          <input type="checkbox" id="check" />
          
            <label className="logo">
            <label htmlFor="check" className="checkbtn">
            <i className='bx bx-menu'></i>
              </label><img src="https://www.kotak.com/content/dam/Kotak/kotak-logo.png" alt="kotak-logo" /></label>
        <ul>

      

<div className="nav-content">
{/*  */}
<Dropdown/>
        <div class="dropdown">
   <li>

    <button class="dropbtn">Accounts &<br />
Deposits
    <i class='bx bx-chevron-down' ></i>    </button>
    <div class="dropdown-content">
      <a href="/">Link 1</a>
      <a href="/">Link 2</a>
      <a href="/">Link 3</a>
    </div>
   </li>

            </div>

        <div class="dropdown">
   <li>

    <button class="dropbtn">Cards &<br />
Fastag
    <i class='bx bx-chevron-down' ></i>    </button>
    <div class="dropdown-content">
      <a href="/">Link 1</a>
      <a href="/">Link 2</a>
      <a href="/">Link 3</a>
    </div>
   </li>

            </div>

        <div class="dropdown">
   <li>

    <button class="dropbtn">Investment &<br />
Insurance
    <i class='bx bx-chevron-down' ></i>    </button>
    <div class="dropdown-content">
      <a href="/">Link 1</a>
      <a href="/">Link 2</a>
      <a href="/">Link 3</a>
    </div>
   </li>

            </div>

        <div class="dropdown">
   <li>

    <button class="dropbtn">Loans 
    <i class='bx bx-chevron-down' ></i>    </button>
    <div class="dropdown-content">
      <a href="/">Link 1</a>
      <a href="/">Link 2</a>
      <a href="/">Link 3</a>
    </div>
   </li>

            </div>

        <div class="dropdown">
   <li>

    <button class="dropbtn">Payments &<br />
Taxes 
    <i class='bx bx-chevron-down' ></i>    </button>
    <div class="dropdown-content">
      <a href="/">Link 1</a>
      <a href="/">Link 2</a>
      <a href="/">Link 3</a>
    </div>
   </li>

            </div>

        <div class="dropdown">
   <li>

    <button class="dropbtn">Offers 
    <i class='bx bx-chevron-down' ></i>    </button>
    <div class="dropdown-content">
      <a href="/">Link 1</a>
      <a href="/">Link 2</a>
      <a href="/">Link 3</a>
    </div>
   </li>

            </div>

        <div class="dropdown">
   <li>

    <button class="dropbtn">Service Request 
    <i class='bx bx-chevron-down' ></i>    </button>
    <div class="dropdown-content">
      <a href="/">Link 1</a>
      <a href="/">Link 2</a>
      <a href="/">Link 3</a>
    </div>
   </li>
   
   </div>
   
  
            </div>

 
  
        </ul>
            <div className='nav-icon'>
              <i className='bx bx-search-alt-2'></i>
              <i className='bx bxs-user-pin'></i>
              <i className='bx bx-user'></i>
            </div>
        </div>

<div className="nav-right">

            <div className="nav-btn">
                <img src="https://cdn-icons-png.flaticon.com/512/219/219983.png?w=740&t=st=1688030514~exp=1688031114~hmac=0ed07c099478076b7e47be5bdf8a09110851919c922092c3986cb01d6de7a12a" alt="profile" />
                <button className='button-23'>              <i className='bx bx-user'></i>
Login</button>

            </div>
</div>
      </nav>
      <Home/>
    </div>
  );
};

export default Navbar;

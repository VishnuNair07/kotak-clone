import React from 'react'
import './BackOnTop.css'
import Footer1 from '../Footer-1/Footer1'

const BackOnTop = () => {
  return (
    <div>
        <div className="back-to-top">

      <p><a href="/"> Back to Top <i class='bx bxs-chevron-up'></i></a></p>
        </div>
        <Footer1/>
    </div>
  )
}

export default BackOnTop

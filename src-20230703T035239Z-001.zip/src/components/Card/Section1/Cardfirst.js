import React from 'react'
import './Cardfirst.css'
import CardSecond from '../Section2/CardSecond'
const Cardfirst = () => {
  return (
    <div>
      <div className="container">
  <div className="card">
    <div className="card-header">
      <img src="https://www.kotak.com/content/dam/Kotak/herosliderbanner/10-99-new-pl-rate-t.jpg.transform/transformer-width-360-height-202/image.jpg" alt="rover" />
    </div>
    <div className="card-body">
      <span className='title'>LOANS</span>
      <h4>
      Personal Loan at incredibly low rates
      </h4>
      <p>
      Quick loan sanction | Part Prepayment available | Loan amount up to Rs.40 lakh
      </p>
      <div className="user">
        <div className="user-info">
          <h5>Know More <i class='bx bxs-chevron-right'></i></h5>
        </div>
      </div>
    </div>
  </div>
  <div className="card">
    <div className="card-header">
      <img className='img-float' src="https://www.kotak.com/content/dam/Kotak/product_card_images/videokyc-card.jpg.transform/transformer-width-360-height-202/image.jpg" alt="ballons" />
    </div>
    <div className="card-body">
      <span className='title'>SAVINGS ACCOUNT</span>
      <h4>
      811 Digital Savings Account
      </h4>
      <p>
      Open a zero balance digital savings account instantly from anywhere with the new Video KYC process
      </p>
      <div className="user">
        <div className="user-info">
          <h5>Open Savings Account <i class='bx bxs-chevron-right'></i></h5>
        </div>
      </div>
    </div>
  </div>
  <div className="card">
    <div className="card-header">
      <img src="https://www.kotak.com/content/dam/Kotak/feature-cards/fd-wef-1-feb.jpg.transform/transformer-width-360-height-202/image.jpg" alt="city" />
    </div>
    <div className="card-body">
      <span className='title'>FIXED DEPOSITS</span>
      <h4>
      Fixed Deposits now at higher rate
      </h4>
      <p>
      Your dreams now within reach! Smartly Invest in a Kotak Fixed Deposit & get 7.20% for 12 months 25 days to less than 2 years. So, turn your dreams into reallty now!
      </p>
      <div className="user">
        <div className="user-info">
          <h5>Invest Now <i class='bx bxs-chevron-right'></i></h5>
         
        </div>
      </div>
    </div>
    </div>
  </div>
  <CardSecond/>
    </div>
  )
}

export default Cardfirst

import React from 'react'
import './CardThird.css'
import BackOnTop from '../../BackonTop/BackOnTop'

const CardThird = () => {
  return (
    <div>
       <div className="container">
  <div className="card">
    <div className="card-header">
      <img src="https://www.kotak.com/content/dam/Kotak/Product-Card-Images-Mobile/keya-pilot.png.transform/transformer-width-360-height-202/image.png" alt="card" />
    </div>
    <div className="card-body">
      <h4>
      Chatting and banking come together!      </h4>
      <p>
      Meet Keya - Your very own virtual assistant from Kotak. Keya is quick & smart and will promptly answer your banking queries round the clock      </p>
      <div className="user">
        <div className="user-info">
          <h5>Experience it now <i class='bx bxs-chevron-right'></i></h5>
        </div>
      </div>
    </div>
  </div>
  <div className="card">
    <div className="card-header">
      <img className='img-float' src="https://www.kotak.com/content/dam/Kotak/herosliderbanner/mb-t.jpg.transform/transformer-width-360-height-202/image.jpg" alt="card" />
    </div>
    <div className="card-body">
      <span className='title'>    Ways to Bank </span>
      <h4>
      Mobile Banking      </h4>
      <p>
      Now, you can experience the benefits of online banking anywhere and anytime, without the need for a computer.      </p>
      <div className="user">
        <div className="user-info">
          <h5>Know more <i class='bx bxs-chevron-right'></i></h5>
        </div>
      </div>
    </div>
  </div>
  <div className="card">
    <div className="card-header">
      <img src="https://www.kotak.com/content/dam/Kotak/Product-Card-Images-Mobile/NB-product-mb.jpg.transform/transformer-width-360-height-202/image.jpg" alt="card" />
    </div>
    <div className="card-body">
      <span className='title'>    Ways to Bank </span>
      <h4>
      Net Banking     </h4>
      <p>
      Net Banking is a convenient way to bank from the comfort of your home or office -  a one stop solution for all of your banking needs.      </p>
      <div className="user">
        <div className="user-info">
          <h5>Know more <i class='bx bxs-chevron-right'></i></h5>
         
        </div>
      </div>
    </div>
    </div>
  <div className="card">
    <div className="card-header">
      <img src="https://www.kotak.com/content/dam/Kotak/deals-offers/dining/EDS-Zomato-PN-t.jpg" alt="card" />
    </div>
    <div className="card-body">
      <span className='title' style={{marginBottom : "1rem"}}>
      Zomato</span>
      {/* <h4>
      Zomato      </h4> */}
      <p style={{marginBottom : '1rem'}}>
      Flat Rs 100 off on select restaurant on MOV of Rs 499 & Rs 75 on select restaurants on Kotak Credit Card- every Friday & Saturday      </p>
      <p style={{color : "#666"}}>Valid till: 15 July 2023</p>
      <div className="user">
        <div className="user-info">
          <h5>Know more <i class='bx bxs-chevron-right'></i></h5>
         
        </div>
      </div>
    </div>
    </div>
  <div className="card">
    <div className="card-header">
      <img src="https://www.kotak.com/content/dam/Kotak/feature-cards/Channel-Red.jpg.transform/transformer-width-360-height-202/image.jpg" alt="card" />
    </div>
    <div className="card-body">
      <h4>
      Tune in to Channel Red
      </h4>
      <p>
      Explore a treasure trove of information about our products and services on Digital Platforms.      </p>
      <div className="user">
        <div className="user-info">
          <h5>Know more <i class='bx bxs-chevron-right'></i></h5>
         
        </div>
      </div>
    </div>
    </div>
  <div className="card">
    <div className="card-header">
      <h3>Rates & Charges</h3>
    </div>
    <div className="card-body">
      <span className='title'>FIXED DEPOSITS</span>
      <h4>
      Fixed Deposits now at higher rate
      </h4>
      <p>
      Your dreams now within reach! Smartly Invest in a Kotak Fixed Deposit & get 7.20% for 12 months 25 days to less than 2 years. So, turn your dreams into reallty now!
      </p>
      <div className="user">
        <div className="user-info">
          <h5>See all rates <i class='bx bxs-chevron-right'></i></h5>
         
        </div>
      </div>
    </div>
    </div>
  </div>
  <BackOnTop/>
    </div>
  )
}

export default CardThird

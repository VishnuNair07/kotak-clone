import React from "react";
import "./CardSecond.css";
import CardThird from "../Section3/CardThird";

const CardSecond = () => {
  return (
    <>
  
    <div className="section2-content">
      <div className="main-img">
        <img
          src="https://www.kotak.com/content/dam/Kotak/article-images/who-is-a-co-applicant-and-the-benefits-to-co-applicant-for-home-loan-article.jpg.transform/transformerWidth750Height460/image.jpg"
          alt="main-img"
        />
        <div className="image-font">
          <p className="story-heading">Stories in focus</p>
          <p
            style={{
              marginTop: ".7rem",
              fontSize: "21px",
              fontWeight: 300,
              color: "#fff",
              margin: "0 0 15px",
              height: "auto",
            }}
          >
            Browse through and read from our collection of specially curated
            stories, for your reading pleasure
          </p>

          <p
            style={{ margin: "1rem 0", display: "flex", alignItems: "center" }}
            className="readmore"
          >
            Read more <i class="bx bxs-chevron-right"></i>
          </p>
        </div>
      </div>
      <div className="stories">
        <p className="story-heading">Stories in focus</p>

        <div className="first-story">
          <img
            src="https://www.kotak.com/content/dam/Kotak/product_card_images/right-way-cc-card.jpg"
            alt="story"
          />
          <p>The Right Way To Apply And Get A New Credit Card</p>
          <i class="bx bxs-chevron-right"></i>
        </div>
        <div className="first-story">
          <img
            src="https://www.kotak.com/content/dam/Kotak/article/home-loan/bhulekh-odisha-guide-t.jpg"
            alt="story"
          />
          <p>
            Bhulekh Odisha 2023: A guide about checking Land records,
            verfication of naksha, ROR Online
          </p>
          <i class="bx bxs-chevron-right"></i>
        </div>
        <div className="first-story">
          <img
            src="https://www.kotak.com/content/dam/Kotak/article/home-loan/stamp-duty-property-t.jpg"
            alt="story"
          />
          <p>
            Stamp Duty & Property Registration Charges in Chennai, Tamil Nadu
          </p>
          <i class="bx bxs-chevron-right"></i>
        </div>
        <div className="first-story">
          <img
            src="https://www.kotak.com/content/dam/Kotak/article/home-loan/plr-prime-lending-t.jpg"
            alt="story"
          />
          <p>
            What is Prime Lending Rate? Meaning, Characteristics in Banking &
            Importance
          </p>
          <i class="bx bxs-chevron-right"></i>
        </div>
        <div className="first-story">
          <img
            src="https://www.kotak.com/content/dam/Kotak/article/home-loan/moratorium-period-meaning-t.jpg"
            alt="story"
          />
          <p>
            Moratorium Period: Meaning, Examples, Importance In Home Loan &
            Comparison with Grace Period
          </p>
          <i class="bx bxs-chevron-right"></i>
        </div>
      </div>
    </div>
      <CardThird/>
    </>
  );
};

export default CardSecond;
